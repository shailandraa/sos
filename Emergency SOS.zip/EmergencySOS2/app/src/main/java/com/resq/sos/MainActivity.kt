// MainActivity.kt
package com.resq.sos
import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.UserProfileChangeRequest
import com.google.firebase.firestore.*
import com.google.firebase.firestore.GeoPoint
import com.google.firebase.messaging.FirebaseMessaging
import com.resq.sos.ui.theme.EmergencySOSTheme
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch


enum class UserType(val label: String) {
    AMBULANCE_DRIVER("Ambulance Driver"),
    PERSON("Person"),
    POLICE("Police")
}

data class SOSAlert(
    val patientId: String = "",
    val patientName: String = "",
    val location: GeoPoint? = null,
    val timestamp: Timestamp? = null,
    val bloodType: String = "",
    val allergies: String = "",
    var isActive: Boolean = false
)

class SOSViewModel : ViewModel() {
    private val db = FirebaseFirestore.getInstance()

    private val _sosAlerts = MutableSharedFlow<SOSAlert>()
    val sosAlerts = _sosAlerts.asSharedFlow()

    private var listenerRegistration: ListenerRegistration? = null

    fun startListening() {
        listenerRegistration = db.collection("sos_alerts")
            .whereEqualTo("isActive", true)
            .addSnapshotListener { snapshots, error ->
                if (error != null) {
                    Log.e("SOSViewModel", "Listen failed", error)
                    return@addSnapshotListener
                }
                if (snapshots != null) {
                    viewModelScope.launch {
                        for (dc in snapshots.documentChanges) {
                            if (dc.type == DocumentChange.Type.ADDED) {
                                val alert = dc.document.toObject(SOSAlert::class.java)
                                _sosAlerts.emit(alert)
                            }
                        }
                    }
                }
            }
    }

    override fun onCleared() {
        listenerRegistration?.remove()
        super.onCleared()
    }
}

class MainActivity : ComponentActivity() {
    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()
    private lateinit var locationPermissionLauncher: ActivityResultLauncher<String>
    private lateinit var fusedLocationClient: FusedLocationProviderClient

    private val CHANNEL_ID = "sos_alerts_channel"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        createNotificationChannel()

        // Subscribe this device to "ambulance" topic
        FirebaseMessaging.getInstance()
            .subscribeToTopic("ambulance")
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    Log.d("FCM", "Subscribed to ambulance topic")
                } else {
                    Log.w("FCM", "Topic subscription failed", task.exception)
                }
            }

            fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        locationPermissionLauncher = registerForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { isGranted ->
            if (isGranted) {
                saveSOSAlert()
            } else {
                Toast.makeText(this, "Location permission is required", Toast.LENGTH_SHORT).show()
            }
        }

        setContent {
            EmergencySOSTheme {
                val context = LocalContext.current
                val viewModel: SOSViewModel = viewModel()
                var currentUser by remember { mutableStateOf(auth.currentUser) }
                var showSignUp by remember { mutableStateOf(true) }

                DisposableEffect(Unit) {
                    val authListener = FirebaseAuth.AuthStateListener { authState ->
                        currentUser = authState.currentUser
                    }
                    auth.addAuthStateListener(authListener)
                    onDispose {
                        auth.removeAuthStateListener(authListener)
                    }
                }

                // Listen for new SOS alerts and show notification
                LaunchedEffect(Unit) {
                    viewModel.startListening()
                }
                LaunchedEffect(viewModel.sosAlerts) {
                    viewModel.sosAlerts.collect { alert ->
                        showNotification(context, alert)
                    }
                }

                when {
                    currentUser != null -> {
                        SOSScreen {
                            if (
                                ContextCompat.checkSelfPermission(
                                    context,
                                    Manifest.permission.ACCESS_FINE_LOCATION
                                ) != PackageManager.PERMISSION_GRANTED
                            ) {
                                locationPermissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
                            } else {
                                saveSOSAlert()
                            }
                        }
                    }
                    showSignUp -> {
                        AuthSignUpScreen { name, bloodType, allergies, email, password, userType ->
                            if (name.isBlank() || bloodType.isBlank() || allergies.isBlank()) {
                                Toast.makeText(context, "Fill in all fields", Toast.LENGTH_SHORT).show()
                            } else if (email.isBlank() || password.isBlank()) {
                                Toast.makeText(context, "Email and password cannot be empty", Toast.LENGTH_SHORT).show()
                            } else {
                                auth.createUserWithEmailAndPassword(email, password)
                                    .addOnCompleteListener { task ->
                                        if (task.isSuccessful) {
                                            val user = auth.currentUser
                                            val profileUpdates = UserProfileChangeRequest.Builder()
                                                .setDisplayName(name)
                                                .build()
                                            user?.updateProfile(profileUpdates)
                                            user?.uid?.let { uid ->
                                                db.collection("users").document(uid).set(
                                                    mapOf(
                                                        "name" to name,
                                                        "bloodType" to bloodType,
                                                        "allergies" to allergies,
                                                        "type" to userType.label
                                                    )
                                                )
                                            }
                                            Toast.makeText(context, "Sign up successful! Please sign in now.", Toast.LENGTH_SHORT).show()
                                            auth.signOut()
                                            showSignUp = false
                                        } else {
                                            Toast.makeText(context, "Sign up failed: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                            }
                        }
                    }
                    else -> {
                        AuthSignInScreen { email, password ->
                            if (email.isBlank() || password.isBlank()) {
                                Toast.makeText(context, "Email and password cannot be empty", Toast.LENGTH_SHORT).show()
                            } else {
                                auth.signInWithEmailAndPassword(email, password)
                                    .addOnCompleteListener { task ->
                                        if (task.isSuccessful) {
                                            Toast.makeText(context, "Sign in successful", Toast.LENGTH_SHORT).show()
                                        } else {
                                            Toast.makeText(context, "Sign in failed: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                            }
                        }
                    }
                }
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun saveSOSAlert() {
        val user = auth.currentUser
        if (user == null) {
            Toast.makeText(this, "Please sign in first", Toast.LENGTH_SHORT).show()
            return
        }

        fusedLocationClient.getCurrentLocation(
            Priority.PRIORITY_HIGH_ACCURACY,
            CancellationTokenSource().token
        ).addOnSuccessListener { location ->
            if (location != null) {
                sendAlertToFirestore(user.uid, location)
            } else {
                Toast.makeText(this, "Unable to obtain location fix", Toast.LENGTH_SHORT).show()
            }
        }.addOnFailureListener { e ->
            Toast.makeText(this, "Location error: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun sendAlertToFirestore(userId: String, location: Location) {
        db.collection("users").document(userId).get().addOnSuccessListener { doc ->
            val name = doc.getString("name") ?: "anonymous"
            val bloodType = doc.getString("bloodType") ?: "Unknown"
            val allergies = doc.getString("allergies") ?: "Unknown"

            val sosAlert = hashMapOf(
                "patientId" to userId,
                "patientName" to name,
                "location" to GeoPoint(location.latitude, location.longitude),
                "timestamp" to FieldValue.serverTimestamp(),
                "bloodType" to bloodType,
                "allergies" to allergies,
                "isActive" to true
            )

            db.collection("sos_alerts").add(sosAlert)
                .addOnSuccessListener {
                    Toast.makeText(this, "SOS alert sent!", Toast.LENGTH_SHORT).show()
                }
                .addOnFailureListener { e ->
                    Toast.makeText(this, "Failed to send alert: ${e.message}", Toast.LENGTH_SHORT).show()
                }
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "SOS Alerts"
            val descriptionText = "Notifications for incoming SOS alerts"
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = descriptionText
            }
            val notificationManager: NotificationManager =
                getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun showNotification(context: Context, alert: SOSAlert) {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = CHANNEL_ID

        val locationString = alert.location?.let { "Lat: %.4f, Long: %.4f".format(it.latitude, it.longitude) } ?: "Location unknown"

        val message = "${alert.patientName} - Blood Type: ${alert.bloodType}, Allergies: ${alert.allergies}. Location: $locationString"

        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("🚨 Emergency Alert!")
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message)) // Show detailed text
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()

        notificationManager.notify(alert.patientId.hashCode(), notification)
    }

}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuthSignUpScreen(
    onSignUp: (name: String, bloodType: String, allergies: String, email: String, password: String, userType: UserType) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var bloodType by remember { mutableStateOf("") }
    var allergies by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var expanded by remember { mutableStateOf(false) }
    var userType by remember { mutableStateOf<UserType?>(null) }
    val context = LocalContext.current

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(text = "Sign Up", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(16.dp))

        ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
            TextField(
                value = userType?.label ?: "Select Type",
                onValueChange = {},
                readOnly = true,
                label = { Text("Type") },
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                modifier = Modifier.menuAnchor()
            )
            ExposedDropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false }
            ) {
                UserType.values().forEach { type ->
                    DropdownMenuItem(
                        text = { Text(type.label) },
                        onClick = {
                            userType = type
                            expanded = false
                        }
                    )
                }
            }
        }

        Spacer(Modifier.height(8.dp))
        TextField(value = name, onValueChange = { name = it }, label = { Text("Name") }, singleLine = true)
        Spacer(Modifier.height(8.dp))
        TextField(value = bloodType, onValueChange = { bloodType = it }, label = { Text("Blood Group") }, singleLine = true)
        Spacer(Modifier.height(8.dp))
        TextField(value = allergies, onValueChange = { allergies = it }, label = { Text("Allergies") }, singleLine = true)
        Spacer(Modifier.height(8.dp))
        TextField(value = email, onValueChange = { email = it }, label = { Text("Email") }, singleLine = true)
        Spacer(Modifier.height(8.dp))
        TextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password") },
            visualTransformation = PasswordVisualTransformation(),
            singleLine = true
        )
        Spacer(Modifier.height(16.dp))
        Button(onClick = {
            if (userType == null) {
                Toast.makeText(context, "Please select a user type", Toast.LENGTH_SHORT).show()
            } else {
                onSignUp(name, bloodType, allergies, email, password, userType!!)
            }
        }) {
            Text("Sign Up")
        }
    }
}

@Composable
fun AuthSignInScreen(onSignIn: (email: String, password: String) -> Unit) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    val context = LocalContext.current

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("Sign In", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(16.dp))
        TextField(value = email, onValueChange = { email = it }, label = { Text("Email") }, singleLine = true)
        Spacer(Modifier.height(8.dp))
        TextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password") },
            visualTransformation = PasswordVisualTransformation(),
            singleLine = true
        )
        Spacer(Modifier.height(16.dp))
        Button(onClick = { onSignIn(email, password) }) {
            Text("Sign In")
        }
    }
}

@Composable
fun SOSScreen(onSOSPressed: () -> Unit) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Button(
            onClick = onSOSPressed,
            colors = ButtonDefaults.buttonColors(containerColor = Color.Red),
            modifier = Modifier.size(200.dp)
        ) {
            Text("SOS", color = Color.White, style = MaterialTheme.typography.headlineMedium)
        }
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewSOSScreen() {
    SOSScreen(onSOSPressed = {})
}
