const functions = require("firebase-functions");
const admin = require("firebase-admin");
admin.initializeApp();

exports.sendSOSNotification = functions.firestore
    .document("sos_alerts/{alertId}")
    .onCreate(async (snap, context) => {
    // Retrieve SOS alert data
      const data = snap.data();
      if (!data) return null;

      const {patientName, location, bloodType, allergies} = data;
      const lat = location.latitude;
      const lng = location.longitude;

      // Build notification payload
      const payload = {
        notification: {
          title: "🚨 SOS Alert",
          body: `${patientName} needs help at ${lat}, ${lng}. ` +
      `Blood: ${bloodType}, Allergies: ${allergies}`,
        },
        data: {
          patientName,
          latitude: lat.toString(),
          longitude: lng.toString(),
          bloodType,
          allergies,
        },
      };

      // Send to "ambulance" topic
      return admin.messaging().sendToTopic("ambulance", payload)
          .then((response) => {
            console.log("Notification sent successfully:", response);
            return null;
          })
          .catch((error) => {
            console.error("Error sending notification:", error);
          });
    });
